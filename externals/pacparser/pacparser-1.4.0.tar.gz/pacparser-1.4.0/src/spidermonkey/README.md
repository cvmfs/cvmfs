This directory contains a trimmed down version of Mozilla SpiderMonkey library version 1.7.
