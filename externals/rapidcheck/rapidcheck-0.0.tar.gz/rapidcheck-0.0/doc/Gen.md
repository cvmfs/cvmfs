`Gen<T>`
=======
_This section is incomplete._
