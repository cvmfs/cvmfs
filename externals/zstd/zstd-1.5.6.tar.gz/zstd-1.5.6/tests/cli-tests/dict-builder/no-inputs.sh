#!/bin/sh
set -v
zstd --train
